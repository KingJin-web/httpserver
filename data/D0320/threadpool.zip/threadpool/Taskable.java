package com.yc.threadpool;

/**
 * 线程的任务
 */
public interface Taskable {
    /*
    这里放要执行的任务..
     */
    public void doTask();
}
