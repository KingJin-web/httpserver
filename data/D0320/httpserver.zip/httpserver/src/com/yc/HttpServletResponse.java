package com.yc;

import java.io.OutputStream;

/**
 * 功能:
 * 1. 根据request中的资源地址以流的方式读取资源
 * 2. 拼接http 的响应
 * 3. 以输出流输出
 */
public class HttpServletResponse {
    private OutputStream oos;
    private HttpServletRequest request;

    public HttpServletResponse(   OutputStream oos, HttpServletRequest request  ){
        this.oos=oos;
        this.request=request;
    }

    public void sendRedirect(){

    }
}
